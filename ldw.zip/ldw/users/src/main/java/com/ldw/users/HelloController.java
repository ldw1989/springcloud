package com.ldw.users;

import com.alibaba.fastjson.JSONObject;
import io.swagger.annotations.Api;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Api("123123")
public class HelloController {

    @GetMapping("/hello")
    public JSONObject hello() {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("a", 1);
        jsonObject.put("b", "22222");
        return jsonObject;
    }



}
